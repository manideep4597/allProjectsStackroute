package com.stackroute.movie.exceptions;

public class NullDetailsException extends Exception {


    public NullDetailsException(String message) {
        super(message);
    }
}
